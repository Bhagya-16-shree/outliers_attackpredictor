# Run APT-Predict locally in VS Code

The app you see in preview is a standard **React 18 + Vite 5 + TypeScript + Tailwind** project. All prediction logic lives client-side in `src/lib/predict.ts`, so it runs offline with no backend, no API keys, and no database.

You have two options. Pick one.

---

## Option A — Frontend only (recommended for hackathon)

This is exactly what's running in the preview. Zero backend, instant demo.

### Steps

1. **Export the code from Lovable**
   - Top-right of Lovable → GitHub → *Connect to GitHub* → push to a new repo
   - OR: GitHub → *Download ZIP*
2. **Open in VS Code**
   - `git clone <your-repo>` then `code <folder>`
   - (Or unzip and `code <folder>`)
3. **Install Node.js 18+** if you don't have it: https://nodejs.org
4. **Install dependencies** in the VS Code terminal:
   ```
   npm install
   ```
5. **Run the dev server**:
   ```
   npm run dev
   ```
6. Open http://localhost:8080 — identical to the preview.

### Build for the demo (optional)
```
npm run build
npm run preview
```
Serves a production build on http://localhost:4173 — faster and what you'd show judges.

### Recommended VS Code extensions
- ESLint
- Tailwind CSS IntelliSense
- ES7+ React/Redux snippets

---

## Option B — Add a real FastAPI backend

Only do this if judges specifically want to see Python. The frontend will call `POST /predict` instead of computing locally. Slightly more impressive on paper, but more moving parts to break during the demo.

### What I would add to your repo

```text
apt-predict/
├── src/                      ← existing React app
├── backend/                  ← NEW
│   ├── main.py               ← FastAPI app with /predict and /simulate
│   ├── predictor.py          ← Same scoring rules as src/lib/predict.ts
│   ├── requirements.txt      ← fastapi, uvicorn, pydantic
│   └── README.md
└── README.md                 ← updated with both run steps
```

### Backend behavior
- `POST /predict` — accepts `BehavioralData` JSON, returns `{ risk_score, predicted_stage, alerts }` using identical rules to the current TS engine
- `GET /simulate?intensity=0.0..1.0` — generates synthetic behavior + prediction in one call (handy for the polling loop)
- CORS enabled for `http://localhost:8080`

### Frontend changes
- Add `VITE_API_URL` env var (defaults to `http://localhost:8000`)
- New `src/lib/api.ts` with a `fetchPrediction(intensity)` helper
- `Index.tsx` polling loop calls the API; falls back to local `predict()` if the backend is unreachable (so the demo never breaks)

### Run steps for Option B
Terminal 1:
```
cd backend
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Terminal 2:
```
npm install
npm run dev
```

---

## My recommendation

Go with **Option A**. For a hackathon:
- One terminal, one command, zero env setup
- No "the backend died 30 seconds before our slot" risk
- The prediction logic is real (rule-based scoring on synthetic behavior) — you're not faking anything, you're just running it in the browser
- Judges see the same polished UI either way

If you want, after you approve I can also generate a clean `README.md` with screenshots-ready setup instructions and a one-paragraph project pitch you can paste into your devpost/submission.

**Tell me: A or B?** (And whether you want the README + pitch generated.)
